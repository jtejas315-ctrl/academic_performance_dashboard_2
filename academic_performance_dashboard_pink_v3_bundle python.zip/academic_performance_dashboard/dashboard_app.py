from __future__ import annotations

import csv
import datetime as dt
import io
from pathlib import Path

import pandas as pd
import streamlit as st

import academic_dashboard as core

BASE_DIR = Path(__file__).resolve().parent

st.set_page_config(
    page_title="Academic Performance Intelligence",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded",
)


def load_data() -> list[core.PerformanceRecord]:
    return core.load_records_with_recovery()


def refresh_data() -> None:
    st.session_state.records = load_data()


if "records" not in st.session_state:
    st.session_state.records = load_data()

if "ui_theme" not in st.session_state:
    st.session_state.ui_theme = "Emerald Light"

with st.sidebar:
    st.markdown("## 🎓 Academic Pulse")
    st.caption("Outcome Analytics • CGPA • Integrity Ledger")
    st.session_state.ui_theme = st.selectbox(
        "Theme Palette",
        ["Rose Pink Light", "Rose Pink Dark"],
        index=0 if st.session_state.ui_theme == "Rose Pink Light" else 1,
    )
    page = st.radio(
        "Navigation",
        [
            "Overview",
            "Student Profiles",
            "Student Records",
            "Add / Edit Record",
            "Import CSV",
            "Reports & Security",
            "Alerts",
        ],
        label_visibility="collapsed",
    )
    st.divider()
    st.markdown("**Thresholds**")
    st.caption(f"Pass mark: {core.PASS_THRESHOLD:.0f} / 100")
    st.caption(f"Honors: {core.HONORS_THRESHOLD:.0f} / 100")
    ok_chain, chain_msg, sha_prefix, backup_count = core.verify_state_integrity()
    st.caption(f"SHA-256: `{sha_prefix}` ({'OK' if ok_chain else 'ALERT'}) · {backup_count} backups")
    if st.button("↻ Reload saved data", use_container_width=True):
        refresh_data()
        st.rerun()

is_dark = st.session_state.ui_theme == "Rose Pink Dark"
theme_attr = "pink-dark" if is_dark else "pink-light"
pink_css_file = BASE_DIR / "static" / "theme_pink.css"
pink_css_content = pink_css_file.read_text(encoding="utf-8") if pink_css_file.exists() else ""

st.markdown(
    f"""
    <div data-theme="{theme_attr}" style="display:none;"></div>
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
      {pink_css_content}
      {"html { filter: none; } :root { --bg-app: #14070e; --bg-card: #210c17; --bg-subtle: #2f1121; --bg-glass: rgba(33, 12, 23, 0.88); --text-main: #fdf2f8; --text-muted: #f4a8cc; --pink-primary: #f472b6; --pink-primary-hover: #ec4899; --pink-secondary: #fb7185; --pink-soft: rgba(244, 114, 182, 0.22); --pink-deep: #180610; --pink-darker: #0d0308; --border-soft: rgba(244, 114, 182, 0.22); --border-strong: rgba(244, 114, 182, 0.45); --shadow-card: 0 16px 36px -12px rgba(0, 0, 0, 0.72); --shadow-hover: 0 24px 48px -12px rgba(244, 114, 182, 0.28); --hero-grad: linear-gradient(125deg, #2b091b 0%, #831843 56%, #db2777 100%); }" if is_dark else ""}
    </style>
    """,
    unsafe_allow_html=True,
)

records: list[core.PerformanceRecord] = st.session_state.records
engine = core.AnalyticsEngine(records)
summary = engine.executive_summary()
profiles = core.build_student_profiles(records)


def header(title: str, subtitle: str) -> None:
    st.markdown(
        f'<div class="hero"><h1>{title}</h1><p>{subtitle}</p></div>',
        unsafe_allow_html=True,
    )


def records_frame(rows: list[core.PerformanceRecord]) -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "Student ID": r.student_id,
                "Student": r.student_name,
                "Subject": r.subject,
                "Score": r.score,
                "Grade": r.grade,
                "Status": r.status.replace("_", " "),
                "Term": r.term,
                "Date": r.recorded_at,
            }
            for r in rows
        ]
    )


if page == "Overview":
    header("Academic Performance Intelligence", "Rose & Magenta Pink analytics workspace with student CGPA tracking, anomaly alerts, and integrity verification.")
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Total Records", f"{summary['count']:,}", delta=f"{len(profiles)} students")
    m2.metric("Average Score", f"{summary['mean']:.1f}%", delta=f"Median {summary['median']:.1f}")
    m3.metric("Pass Rate", f"{summary['pass_rate']:.1f}%", delta=f"{summary['honors_count']} honors")
    m4.metric(
        "At-Risk Flags",
        f"{summary['at_risk_count']}",
        delta="Needs follow-up" if summary["at_risk_count"] else "All passing",
        delta_color="inverse",
    )

    left, right = st.columns([1.45, 1])
    with left:
        st.subheader("Subject Performance & Trend Slopes")
        subjects = summary["subjects"]
        if subjects:
            chart_df = pd.DataFrame({"Subject": list(subjects), "Average": [x["avg"] for x in subjects.values()]})
            st.bar_chart(chart_df, x="Subject", y="Average", color="#db2777")
            st.dataframe(
                pd.DataFrame(
                    [
                        {
                            "Subject": s,
                            "Average": v["avg"],
                            "Std Dev": v["stdev"],
                            "Students": v["count"],
                            "Range": f"{v['min']:.0f} – {v['max']:.0f}",
                            "Trend Slope": f"{v['slope']:+.2f}",
                        }
                        for s, v in subjects.items()
                    ]
                ),
                use_container_width=True,
                hide_index=True,
            )
        else:
            st.info("No subject records yet. Add a record or import a CSV to populate analytics.")

    with right:
        st.subheader("Grade Distribution")
        if records:
            grade_order = ["A+", "A", "B", "C", "D", "F"]
            counts = {g: sum(1 for r in records if r.grade == g) for g in grade_order}
            grade_df = pd.DataFrame({"Grade": grade_order, "Records": [counts[g] for g in grade_order]})
            st.bar_chart(grade_df, x="Grade", y="Records", color="#ec4899")
            st.markdown("**Cohort Outcome Split**")
            st.write(f"🏅 Honors (≥ {core.HONORS_THRESHOLD:.0f}%): **{summary['honors_count']}**")
            st.write(f"✅ Pass ({core.PASS_THRESHOLD:.0f}–84.9%): **{sum(1 for r in records if r.status == 'PASS')}**")
            st.write(f"⚠️ At Risk (< {core.PASS_THRESHOLD:.0f}%): **{summary['at_risk_count']}**")
        else:
            st.info("No records available yet.")

    st.subheader("Top & At-Risk Student Profiles")
    if profiles:
        prof_df = pd.DataFrame(profiles).rename(
            columns={
                "student_id": "ID",
                "student_name": "Student",
                "subjects_count": "Subjects",
                "average": "Avg %",
                "cgpa_10": "CGPA (10)",
                "best_subject": "Strongest",
                "weakest_subject": "Weakest",
                "standing": "Standing",
            }
        )
        st.dataframe(prof_df.drop(columns=["at_risk_subjects"]), use_container_width=True, hide_index=True)

elif page == "Student Profiles":
    header("Student Profiles & CGPA", "Aggregated per-student averages, 10-point CGPA, strongest/weakest subjects, and academic standing.")
    if not profiles:
        st.info("No student records available.")
    else:
        standing_filter = st.selectbox("Filter by Standing", ["All", "HONORS", "GOOD_STANDING", "AT_RISK"])
        shown_profiles = profiles if standing_filter == "All" else [p for p in profiles if p["standing"] == standing_filter]
        prof_df = pd.DataFrame(shown_profiles).rename(
            columns={
                "student_id": "Student ID",
                "student_name": "Student Name",
                "subjects_count": "Subjects",
                "average": "Average (%)",
                "cgpa_10": "CGPA (10-pt)",
                "best_subject": "Strongest Subject",
                "weakest_subject": "Weakest Subject",
                "at_risk_subjects": "Below Pass",
                "standing": "Standing",
            }
        )
        st.dataframe(prof_df, use_container_width=True, hide_index=True)
        st.download_button(
            "⬇ Download Student Profiles CSV",
            prof_df.to_csv(index=False).encode("utf-8"),
            "student_profiles_cgpa.csv",
            "text/csv",
        )

elif page == "Student Records":
    header("Student Records", "Multi-facet search, filtering, sorting, and CSV export.")
    c1, c2, c3, c4 = st.columns([1.5, 1, 1, 1])
    query = c1.text_input("Search", placeholder="Name, ID, subject or term")
    subjects = sorted({r.subject for r in records})
    selected_subject = c2.selectbox("Subject", ["All"] + subjects)
    selected_status = c3.selectbox("Status", ["All", "PASS", "HONORS", "AT_RISK"])
    sort_mode = c4.selectbox("Sort By", ["Newest Date", "Highest Score", "Lowest Score", "Student ID"])

    filtered = records
    if query.strip():
        q = query.strip().casefold()
        filtered = [
            r
            for r in filtered
            if q in r.student_id.casefold()
            or q in r.student_name.casefold()
            or q in r.subject.casefold()
            or q in r.term.casefold()
        ]
    if selected_subject != "All":
        filtered = [r for r in filtered if r.subject == selected_subject]
    if selected_status != "All":
        filtered = [r for r in filtered if r.status == selected_status]

    if sort_mode == "Highest Score":
        filtered = sorted(filtered, key=lambda r: r.score, reverse=True)
    elif sort_mode == "Lowest Score":
        filtered = sorted(filtered, key=lambda r: r.score)
    elif sort_mode == "Student ID":
        filtered = sorted(filtered, key=lambda r: (r.student_id, r.subject))
    else:
        filtered = sorted(filtered, key=lambda r: r.recorded_at, reverse=True)

    st.caption(f"Showing {len(filtered)} of {len(records)} records")
    st.dataframe(records_frame(filtered), use_container_width=True, hide_index=True)
    if filtered:
        csv_bytes = records_frame(filtered).to_csv(index=False).encode("utf-8")
        st.download_button("⬇ Download filtered records CSV", csv_bytes, "filtered_records.csv", "text/csv")

elif page == "Add / Edit Record":
    header("Add or Manage Records", "Create validated entries or update/remove an existing student record with SHA-256 atomic saves.")
    tab_add, tab_edit = st.tabs(["➕ Add New Record", "✏️ Update / Delete Existing"])

    with tab_add:
        with st.form("add_record_form", clear_on_submit=True):
            c1, c2 = st.columns(2)
            sid = c1.text_input("Student ID", placeholder="STU015")
            student_name = c2.text_input("Student name", placeholder="Student full name")
            subject = c1.text_input("Subject", placeholder="Mathematics")
            score = c2.number_input("Score", min_value=0.0, max_value=100.0, step=0.5)
            term = c1.text_input("Term", value="Term 1")
            submitted = st.form_submit_button("Save record", type="primary", use_container_width=True)
        if submitted:
            try:
                rec = core.PerformanceRecord(student_id=sid, student_name=student_name, subject=subject, score=score, term=term)
                duplicate = any(
                    r.student_id == rec.student_id
                    and r.subject.casefold() == rec.subject.casefold()
                    and r.term.casefold() == rec.term.casefold()
                    for r in records
                )
                if duplicate:
                    st.warning("This student already has a record for this subject and term. Use the Update tab to modify it.")
                elif len(records) >= core.MAX_RECORDS:
                    st.error(f"Record capacity ({core.MAX_RECORDS}) reached.")
                else:
                    records.append(rec)
                    core.save_records_atomic(records)
                    st.session_state.records = records
                    st.success(f"Saved {rec.student_id} — {rec.subject}: {rec.score:.1f} ({rec.grade})")
                    st.rerun()
            except (ValueError, core.SecurityError, OSError) as exc:
                st.error(str(exc))

    with tab_edit:
        if not records:
            st.info("No records available to edit.")
        else:
            options = [f"{i}: {r.student_id} — {r.student_name} | {r.subject} ({r.term}) = {r.score}" for i, r in enumerate(records)]
            selected_idx = st.selectbox("Select record", range(len(options)), format_func=lambda idx: options[idx])
            target = records[selected_idx]
            with st.form("edit_record_form"):
                new_score = st.number_input("Updated Score", min_value=0.0, max_value=100.0, value=float(target.score), step=0.5)
                new_term = st.text_input("Updated Term", value=target.term)
                b1, b2 = st.columns(2)
                update_btn = b1.form_submit_button("Update Score", type="primary", use_container_width=True)
                delete_btn = b2.form_submit_button("Delete Record", use_container_width=True)
            if update_btn:
                try:
                    updated = core.PerformanceRecord(
                        student_id=target.student_id,
                        student_name=target.student_name,
                        subject=target.subject,
                        score=new_score,
                        term=new_term,
                        recorded_at=dt.date.today().isoformat(),
                    )
                    records[selected_idx] = updated
                    core.save_records_atomic(records)
                    core.write_audit_log("UPDATE_RECORD", f"{updated.student_id} {updated.subject} -> {updated.score}")
                    st.session_state.records = records
                    st.success("Record updated and SHA-256 manifest refreshed.")
                    st.rerun()
                except Exception as exc:
                    st.error(str(exc))
            if delete_btn:
                removed = records.pop(selected_idx)
                core.save_records_atomic(records)
                core.write_audit_log("DELETE_RECORD", f"{removed.student_id} {removed.subject}")
                st.session_state.records = records
                st.warning(f"Deleted {removed.student_id} — {removed.subject}.")
                st.rerun()

elif page == "Import CSV":
    header("Bulk CSV Import", "Upload a UTF-8 CSV file with preview, strict validation, and duplicate prevention.")
    st.markdown("Required columns: `student_id, student_name, subject, score` (optional: `term, recorded_at`)")
    upload = st.file_uploader("Choose CSV file", type=["csv"])
    if upload is not None:
        try:
            decoded = upload.getvalue().decode("utf-8-sig")
            reader = csv.DictReader(io.StringIO(decoded))
            required = {"student_id", "student_name", "subject", "score"}
            headers = {h.strip().lower() for h in (reader.fieldnames or [])}
            if not required.issubset(headers):
                st.error("CSV missing required columns: student_id, student_name, subject, score")
            else:
                raw_rows = list(reader)
                st.caption(f"Preview: {len(raw_rows)} row(s)")
                st.dataframe(raw_rows[:20], use_container_width=True, hide_index=True)
                if st.button("Import valid rows", type="primary"):
                    added, errors = 0, []
                    seen = {(r.student_id, r.subject.casefold(), r.term.casefold()) for r in records}
                    for line, raw in enumerate(raw_rows, start=2):
                        row = {k.strip().lower(): v for k, v in raw.items() if k}
                        try:
                            rec = core.PerformanceRecord(
                                student_id=row.get("student_id", ""),
                                student_name=row.get("student_name", ""),
                                subject=row.get("subject", ""),
                                score=row.get("score", ""),
                                term=row.get("term") or "Term 1",
                                recorded_at=row.get("recorded_at") or dt.date.today().isoformat(),
                            )
                            key = (rec.student_id, rec.subject.casefold(), rec.term.casefold())
                            if key in seen:
                                raise ValueError("Duplicate student/subject/term record")
                            if len(records) + added >= core.MAX_RECORDS:
                                raise ValueError(f"Record limit ({core.MAX_RECORDS}) reached")
                            records.append(rec)
                            seen.add(key)
                            added += 1
                        except Exception as exc:
                            errors.append(f"Row {line}: {exc}")
                    if added:
                        core.save_records_atomic(records)
                        st.session_state.records = records
                    st.success(f"Imported {added} valid record(s).")
                    if errors:
                        st.warning(f"Skipped {len(errors)} row(s):")
                        st.code("
".join(errors[:20]))
                    st.rerun()
        except UnicodeDecodeError:
            st.error("Unable to read CSV as UTF-8. Please save the file as UTF-8 and try again.")
        except Exception as exc:
            st.error(f"Import failed: {exc}")

elif page == "Reports & Security":
    header("Reports & Security Ledger", "Export formula-safe CSV, Markdown, and PNG reports, and inspect SHA-256 & HMAC audit logs.")
    c_rep, c_sec = st.columns([1.15, 1])
    with c_rep:
        st.subheader("Generate Reports")
        base_name = st.text_input("Report name", value="academic_report")
        if st.button("Generate CSV, Markdown & Chart", type="primary"):
            try:
                files = core.export_reports(records, base_name)
                st.success("Report files generated successfully.")
                for path in files:
                    st.write(f"📄 `{path.relative_to(BASE_DIR)}`")
            except (ValueError, core.SecurityError, OSError) as exc:
                st.error(str(exc))
        st.divider()
        existing_exports = sorted(core.EXPORT_DIR.glob("*")) if core.EXPORT_DIR.exists() else []
        if existing_exports:
            st.subheader("Available Exports")
            for path in existing_exports:
                if path.is_file() and path.suffix.lower() in {".csv", ".md", ".png"}:
                    mime = {".csv": "text/csv", ".md": "text/markdown", ".png": "image/png"}.get(path.suffix.lower(), "application/octet-stream")
                    st.download_button(f"⬇ {path.name}", path.read_bytes(), path.name, mime, key=f"download_{path.name}")

    with c_sec:
        st.subheader("Integrity & Audit Trail")
        ok_chain, chain_msg, sha_prefix, backup_count = core.verify_state_integrity()
        if ok_chain:
            st.success(f"{chain_msg} (`{sha_prefix}…`, {backup_count} rotating backups)")
        else:
            st.error(f"{chain_msg} (`{sha_prefix}…`)")
        audit_lines = core.get_recent_audit_entries(12)
        if audit_lines:
            st.code("
".join(audit_lines), language="text")
        else:
            st.caption("No audit events logged yet.")

elif page == "Alerts":
    header("Anomaly & At-Risk Alerts", "Identify below-pass scores (< 50) and statistical outliers (|z| >= 2.0) for academic intervention.")
    alerts = engine.detect_anomalies()
    st.metric("Active Alerts", len(alerts))
    if alerts:
        alert_rows = [
            {
                "Student ID": rec.student_id,
                "Student": rec.student_name,
                "Subject": rec.subject,
                "Score": rec.score,
                "Grade": rec.grade,
                "Z-score": z,
                "Reason": reason,
            }
            for rec, z, reason in alerts
        ]
        st.dataframe(alert_rows, use_container_width=True, hide_index=True)
        st.info("A low-score alert is a flag for academic mentoring, not a final conclusion about the student.")
    else:
        st.success("No alerts for the current records.")

st.caption("Academic Performance Intelligence · Rose Pink Edition · CLI preserved in academic_dashboard.py")
