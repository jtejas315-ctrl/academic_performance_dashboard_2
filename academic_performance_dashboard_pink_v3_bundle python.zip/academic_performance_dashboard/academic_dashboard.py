from __future__ import annotations

import csv
import datetime as dt
import hashlib
import hmac
import json
import math
import os
import re
import statistics
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

try:
    import matplotlib.pyplot as plt  # type: ignore

    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False


# ==============================================================================
# Configuration & Security Constants
# ==============================================================================
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = (BASE_DIR / "data").resolve()
EXPORT_DIR = (BASE_DIR / "exports").resolve()
QUARANTINE_DIR = (DATA_DIR / "quarantine").resolve()
BACKUP_DIR = (DATA_DIR / "backups").resolve()

STATE_FILE = DATA_DIR / "records.json"
MANIFEST_FILE = DATA_DIR / "records.sha256"
AUDIT_LOG_FILE = EXPORT_DIR / "audit.log"

MAX_RECORDS = 5000
MAX_IMPORT_ROWS = 1000
MAX_TEXT_LEN = 80
PASS_THRESHOLD = 50.0
HONORS_THRESHOLD = 85.0
FORMULA_TRIGGERS = ("=", "+", "-", "@", "\t", "\r")
CONTROL_CHAR_RE = re.compile(r"[\x00-\x1f\x7f]")
ID_RE = re.compile(r"^[A-Za-z0-9_-]{2,24}$")
# Ephemeral process key for session audit MACs (not a hardcoded secret)
SESSION_HMAC_KEY = os.urandom(32)


# ==============================================================================
# Security & Path Sandboxing Helpers
# ==============================================================================
class SecurityError(ValueError):
    """Raised when an operation violates a security wall."""


def ensure_directories() -> None:
    for folder in (DATA_DIR, EXPORT_DIR, QUARANTINE_DIR, BACKUP_DIR):
        folder.mkdir(parents=True, exist_ok=True)


def resolve_sandboxed_path(user_path: str, allowed_root: Path, default_name: str) -> Path:
    """Resolve a user-supplied filename/path strictly inside allowed_root."""
    raw = user_path.strip()
    if not raw:
        candidate = (allowed_root / default_name).resolve()
    else:
        p = Path(raw)
        # Disallow drive letters or leading slashes escaping the sandbox
        if p.is_absolute() or re.match(r"^[A-Za-z]:", raw):
            raise SecurityError("Absolute paths are not permitted; provide a relative name.")
        candidate = (allowed_root / p).resolve()

    if candidate != allowed_root and allowed_root not in candidate.parents:
        raise SecurityError(f"Path traversal blocked outside '{allowed_root.name}/'.")
    return candidate


def sanitize_text(value: Any, field_name: str, max_len: int = MAX_TEXT_LEN) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field_name} must be text.")
    cleaned = CONTROL_CHAR_RE.sub("", value).strip()
    cleaned = re.sub(r"\s+", " ", cleaned)
    if not cleaned:
        raise ValueError(f"{field_name} cannot be blank.")
    if len(cleaned) > max_len:
        raise ValueError(f"{field_name} exceeds maximum length of {max_len}.")
    return cleaned


def validate_score(value: Any) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float, str)):
        raise ValueError("Score must be a numeric value.")
    try:
        score = float(str(value).strip())
    except ValueError as exc:
        raise ValueError("Score must be a valid number.") from exc
    if math.isnan(score) or math.isinf(score):
        raise SecurityError("Non-finite score (NaN/Inf) rejected.")
    if not (0.0 <= score <= 100.0):
        raise ValueError("Score must be between 0 and 100.")
    return round(score, 2)


def neutralize_csv_cell(val: Any) -> str:
    text = str(val)
    if text.startswith(FORMULA_TRIGGERS):
        return "'" + text
    return text


def compute_sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sign_audit_line(line: str) -> str:
    digest = hmac.new(SESSION_HMAC_KEY, line.encode("utf-8"), hashlib.sha256).hexdigest()[:16]
    return f"{line} | sig={digest}"


def write_audit_log(action: str, detail: str) -> None:
    ensure_directories()
    timestamp = dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")
    safe_detail = CONTROL_CHAR_RE.sub(" ", detail)[:240]
    entry = sign_audit_line(f"[{timestamp}] {action}: {safe_detail}")
    try:
        with AUDIT_LOG_FILE.open("a", encoding="utf-8") as fh:
            fh.write(entry + "\n")
    except OSError:
        pass  # Audit logging failure should not crash primary workflow


# ==============================================================================
# Domain Model & Analytics Engine
# ==============================================================================
@dataclass
class PerformanceRecord:
    student_id: str
    student_name: str
    subject: str
    score: float
    term: str = "Term 1"
    recorded_at: str = field(
        default_factory=lambda: dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d")
    )

    def __post_init__(self) -> None:
        sid = sanitize_text(self.student_id, "Student ID", 24).upper()
        if not ID_RE.match(sid):
            raise ValueError("Student ID must be 2-24 alphanumeric/dash/underscore chars.")
        self.student_id = sid
        self.student_name = sanitize_text(self.student_name, "Student Name", MAX_TEXT_LEN)
        self.subject = sanitize_text(self.subject, "Subject", 50)
        self.score = validate_score(self.score)
        self.term = sanitize_text(self.term, "Term", 24)
        self.recorded_at = sanitize_text(self.recorded_at, "Date", 20)

    @property
    def grade(self) -> str:
        if self.score >= 90:
            return "A+"
        if self.score >= 80:
            return "A"
        if self.score >= 70:
            return "B"
        if self.score >= 60:
            return "C"
        if self.score >= PASS_THRESHOLD:
            return "D"
        return "F"

    @property
    def status(self) -> str:
        if self.score >= HONORS_THRESHOLD:
            return "HONORS"
        if self.score >= PASS_THRESHOLD:
            return "PASS"
        return "AT_RISK"


class AnalyticsEngine:
    """Computes summary metrics, z-scores, trend slopes, and anomaly flags."""

    def __init__(self, records: list[PerformanceRecord]) -> None:
        self.records = records

    def executive_summary(self) -> dict[str, Any]:
        if not self.records:
            return {
                "count": 0,
                "mean": 0.0,
                "median": 0.0,
                "stdev": 0.0,
                "min": 0.0,
                "max": 0.0,
                "pass_rate": 0.0,
                "at_risk_count": 0,
                "honors_count": 0,
                "subjects": {},
            }

        scores = [r.score for r in self.records]
        mean_val = round(statistics.fmean(scores), 2)
        median_val = round(statistics.median(scores), 2)
        stdev_val = round(statistics.stdev(scores), 2) if len(scores) > 1 else 0.0
        pass_count = sum(1 for r in self.records if r.score >= PASS_THRESHOLD)
        honors_count = sum(1 for r in self.records if r.score >= HONORS_THRESHOLD)
        at_risk_count = sum(1 for r in self.records if r.score < PASS_THRESHOLD)

        return {
            "count": len(self.records),
            "mean": mean_val,
            "median": median_val,
            "stdev": stdev_val,
            "min": min(scores),
            "max": max(scores),
            "pass_rate": round((pass_count / len(self.records)) * 100.0, 1),
            "at_risk_count": at_risk_count,
            "honors_count": honors_count,
            "subjects": self.subject_breakdown(),
        }

    def subject_breakdown(self) -> dict[str, dict[str, Any]]:
        grouped: dict[str, list[float]] = {}
        for r in self.records:
            grouped.setdefault(r.subject, []).append(r.score)

        breakdown: dict[str, dict[str, Any]] = {}
        for subj, vals in sorted(grouped.items()):
            avg = statistics.fmean(vals)
            sd = statistics.stdev(vals) if len(vals) > 1 else 0.0
            if len(vals) >= 2:
                xs = list(range(len(vals)))
                x_mean = statistics.fmean(xs)
                num = sum((x - x_mean) * (y - avg) for x, y in zip(xs, vals))
                den = sum((x - x_mean) ** 2 for x in xs)
                slope = round(num / den, 2) if den else 0.0
            else:
                slope = 0.0

            breakdown[subj] = {
                "count": len(vals),
                "avg": round(avg, 2),
                "stdev": round(sd, 2),
                "min": min(vals),
                "max": max(vals),
                "slope": slope,
            }
        return breakdown

    def detect_anomalies(self) -> list[tuple[PerformanceRecord, float, str]]:
        """Flag statistical z-score outliers (|z| >= 2.0) and failing scores."""
        by_subj: dict[str, list[float]] = {}
        for r in self.records:
            by_subj.setdefault(r.subject, []).append(r.score)

        findings: list[tuple[PerformanceRecord, float, str]] = []
        for r in self.records:
            vals = by_subj[r.subject]
            reasons: list[str] = []
            z_score = 0.0
            if len(vals) >= 3:
                mean_s = statistics.fmean(vals)
                sd_s = statistics.stdev(vals)
                if sd_s > 1e-6:
                    z_score = round((r.score - mean_s) / sd_s, 2)
                    if abs(z_score) >= 2.0:
                        reasons.append(f"Outlier z={z_score:+.2f}")
            if r.score < PASS_THRESHOLD:
                reasons.append(f"Below pass ({PASS_THRESHOLD})")
            elif r.score == 100.0 or r.score == 0.0:
                reasons.append("Boundary extreme")

            if reasons:
                findings.append((r, z_score, "; ".join(reasons)))
        return findings


# ==============================================================================
# Atomic Persistence, Integrity & Seed Data
# ==============================================================================
def build_seed_records() -> list[PerformanceRecord]:
    raw_rows = [
        ("STU001", "Aarav Sharma", "Mathematics", 92.0, "Term 1", "2026-08-10"),
        ("STU001", "Aarav Sharma", "Physics", 88.5, "Term 1", "2026-08-12"),
        ("STU001", "Aarav Sharma", "Computer Science", 96.0, "Term 1", "2026-08-14"),
        ("STU002", "Diya Nair", "Mathematics", 78.0, "Term 1", "2026-08-10"),
        ("STU002", "Diya Nair", "Physics", 81.0, "Term 1", "2026-08-12"),
        ("STU002", "Diya Nair", "Computer Science", 84.5, "Term 1", "2026-08-14"),
        ("STU003", "Rohan Verma", "Mathematics", 42.0, "Term 1", "2026-08-10"),
        ("STU003", "Rohan Verma", "Physics", 50.0, "Term 1", "2026-08-12"),
        ("STU003", "Rohan Verma", "Computer Science", 61.5, "Term 1", "2026-08-14"),
        ("STU004", "Ananya Rao", "Mathematics", 89.0, "Term 1", "2026-08-10"),
        ("STU004", "Ananya Rao", "Physics", 91.5, "Term 1", "2026-08-12"),
        ("STU004", "Ananya Rao", "Computer Science", 87.0, "Term 1", "2026-08-14"),
        ("STU005", "Kabir Menon", "Mathematics", 67.5, "Term 1", "2026-08-10"),
        ("STU005", "Kabir Menon", "Physics", 38.0, "Term 1", "2026-08-12"),
        ("STU005", "Kabir Menon", "Computer Science", 72.0, "Term 1", "2026-08-14"),
        ("STU006", "Meera Iyer", "Mathematics", 100.0, "Term 1", "2026-08-10"),
        ("STU006", "Meera Iyer", "Physics", 94.0, "Term 1", "2026-08-12"),
        ("STU006", "Meera Iyer", "Computer Science", 98.0, "Term 1", "2026-08-14"),
        ("STU007", "Vikram Reddy", "Mathematics", 55.0, "Term 1", "2026-08-10"),
        ("STU007", "Vikram Reddy", "Physics", 59.5, "Term 1", "2026-08-12"),
        ("STU007", "Vikram Reddy", "Computer Science", 64.0, "Term 1", "2026-08-14"),
        ("STU008", "Sanya Gupta", "Mathematics", 83.0, "Term 1", "2026-08-10"),
        ("STU008", "Sanya Gupta", "Physics", 79.0, "Term 1", "2026-08-12"),
        ("STU008", "Sanya Gupta", "Computer Science", 86.0, "Term 1", "2026-08-14"),
        ("STU009", "Arjun Kulkarni", "Mathematics", 74.0, "Term 1", "2026-08-10"),
        ("STU009", "Arjun Kulkarni", "Physics", 70.5, "Term 1", "2026-08-12"),
        ("STU009", "Arjun Kulkarni", "Computer Science", 29.0, "Term 1", "2026-08-14"),
        ("STU010", "Neha Joshi", "Mathematics", 85.0, "Term 1", "2026-08-10"),
        ("STU010", "Neha Joshi", "Physics", 88.0, "Term 1", "2026-08-12"),
        ("STU010", "Neha Joshi", "Computer Science", 91.0, "Term 1", "2026-08-14"),
        ("STU011", "Devansh Patel", "Mathematics", 62.0, "Term 1", "2026-08-10"),
        ("STU011", "Devansh Patel", "Physics", 66.0, "Term 1", "2026-08-12"),
        ("STU011", "Devansh Patel", "Computer Science", 69.5, "Term 1", "2026-08-14"),
        ("STU012", "Tara Deshmukh", "Mathematics", 0.0, "Term 1", "2026-08-10"),
        ("STU012", "Tara Deshmukh", "Physics", 76.0, "Term 1", "2026-08-12"),
    ]
    return [
        PerformanceRecord(
            student_id=sid,
            student_name=name,
            subject=subj,
            score=score,
            term=term,
            recorded_at=date_str,
        )
        for sid, name, subj, score, term, date_str in raw_rows
    ]


def quarantine_corrupt_state(reason: str) -> None:
    if STATE_FILE.exists():
        stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        q_path = QUARANTINE_DIR / f"records_corrupt_{stamp}.json"
        try:
            os.replace(STATE_FILE, q_path)
            write_audit_log("QUARANTINE", f"Moved corrupt state to {q_path.name} ({reason})")
        except OSError:
            pass


def save_records_atomic(records: list[PerformanceRecord]) -> None:
    if len(records) > MAX_RECORDS:
        raise SecurityError(f"Record capacity ({MAX_RECORDS}) exceeded.")
    ensure_directories()

    payload = {
        "version": 1,
        "updated_at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
        "records": [asdict(r) for r in records],
    }
    serialized = json.dumps(payload, indent=2).encode("utf-8")
    digest = compute_sha256_bytes(serialized)

    tmp_data = DATA_DIR / ".records.json.tmp"
    tmp_sig = DATA_DIR / ".records.sha256.tmp"

    with tmp_data.open("wb") as fh:
        fh.write(serialized)
        fh.flush()
        os.fsync(fh.fileno())

    with tmp_sig.open("w", encoding="utf-8") as fh:
        fh.write(digest + "\n")
        fh.flush()
        os.fsync(fh.fileno())

    os.replace(tmp_data, STATE_FILE)
    os.replace(tmp_sig, MANIFEST_FILE)

    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup_path = BACKUP_DIR / f"records_{stamp}.json"
    try:
        backup_path.write_bytes(serialized)
        backups = sorted(BACKUP_DIR.glob("records_*.json"))
        for old in backups[:-10]:
            old.unlink(missing_ok=True)
    except OSError:
        pass

    write_audit_log("SAVE_STATE", f"Persisted {len(records)} records (sha256={digest[:12]}...)")


def load_records_with_recovery() -> list[PerformanceRecord]:
    ensure_directories()

    if not STATE_FILE.exists():
        seeded = build_seed_records()
        save_records_atomic(seeded)
        write_audit_log("SEED_DATA", f"Initialized {len(seeded)} benchmark records.")
        return seeded

    try:
        raw_bytes = STATE_FILE.read_bytes()
        actual_hash = compute_sha256_bytes(raw_bytes)
        if MANIFEST_FILE.exists():
            expected_hash = MANIFEST_FILE.read_text(encoding="utf-8").strip().split()[0]
            if expected_hash and not hmac.compare_digest(actual_hash, expected_hash):
                raise SecurityError("SHA-256 checksum mismatch (possible tampering/corruption).")

        data = json.loads(raw_bytes.decode("utf-8"))
        if not isinstance(data, dict) or not isinstance(data.get("records"), list):
            raise ValueError("Invalid JSON schema.")

        loaded: list[PerformanceRecord] = []
        for item in data["records"][:MAX_RECORDS]:
            if not isinstance(item, dict):
                raise ValueError("Record entry must be an object.")
            loaded.append(
                PerformanceRecord(
                    student_id=item["student_id"],
                    student_name=item["student_name"],
                    subject=item["subject"],
                    score=item["score"],
                    term=item.get("term", "Term 1"),
                    recorded_at=item.get("recorded_at", "2026-08-10"),
                )
            )
        return loaded

    except Exception as exc:
        quarantine_corrupt_state(str(exc))
        backups = sorted(BACKUP_DIR.glob("records_*.json"), reverse=True)
        for b_path in backups:
            try:
                b_data = json.loads(b_path.read_text(encoding="utf-8"))
                recovered = [
                    PerformanceRecord(
                        student_id=x["student_id"],
                        student_name=x["student_name"],
                        subject=x["subject"],
                        score=x["score"],
                        term=x.get("term", "Term 1"),
                        recorded_at=x.get("recorded_at", "2026-08-10"),
                    )
                    for x in b_data.get("records", [])[:MAX_RECORDS]
                ]
                save_records_atomic(recovered)
                write_audit_log("RECOVER_BACKUP", f"Restored from {b_path.name}")
                print(f"[!] State issue detected ({exc}). Restored from backup '{b_path.name}'.")
                return recovered
            except Exception:
                continue

        fallback = build_seed_records()
        save_records_atomic(fallback)
        print(f"[!] State issue detected ({exc}). Re-initialized from clean benchmark seed.")
        return fallback


# ==============================================================================
# Import, Export & Visualization
# ==============================================================================
def import_csv_records(filename: str, existing: list[PerformanceRecord]) -> tuple[int, list[str]]:
    path = resolve_sandboxed_path(filename, DATA_DIR, "import.csv")
    if not path.exists() or not path.is_file():
        raise FileNotFoundError(f"CSV file not found in data/: {path.name}")

    added = 0
    errors: list[str] = []
    with path.open("r", encoding="utf-8-sig", newline="") as fh:
        reader = csv.DictReader(fh)
        required = {"student_id", "student_name", "subject", "score"}
        if not reader.fieldnames or not required.issubset({h.strip().lower() for h in reader.fieldnames}):
            raise ValueError("CSV must contain headers: student_id, student_name, subject, score")

        for idx, row in enumerate(reader, start=2):
            if idx - 1 > MAX_IMPORT_ROWS:
                errors.append(f"Row {idx}: Import cap ({MAX_IMPORT_ROWS}) reached; remaining rows skipped.")
                break
            if len(existing) + added >= MAX_RECORDS:
                errors.append(f"Row {idx}: Global record limit ({MAX_RECORDS}) reached.")
                break
            norm = {k.strip().lower(): v for k, v in row.items() if k}
            try:
                rec = PerformanceRecord(
                    student_id=norm.get("student_id", ""),
                    student_name=norm.get("student_name", ""),
                    subject=norm.get("subject", ""),
                    score=norm.get("score", ""),
                    term=norm.get("term") or "Term 1",
                    recorded_at=norm.get("recorded_at") or dt.date.today().isoformat(),
                )
                existing.append(rec)
                added += 1
            except Exception as exc:
                errors.append(f"Row {idx}: {exc}")

    if added > 0:
        save_records_atomic(existing)
    write_audit_log("BULK_IMPORT", f"File={path.name}, added={added}, errors={len(errors)}")
    return added, errors


def export_reports(records: list[PerformanceRecord], base_name: str = "academic_report") -> list[Path]:
    clean_stem = re.sub(r"[^A-Za-z0-9_-]", "_", base_name.strip()) or "academic_report"
    csv_path = resolve_sandboxed_path(f"{clean_stem}.csv", EXPORT_DIR, "report.csv")
    md_path = resolve_sandboxed_path(f"{clean_stem}.md", EXPORT_DIR, "report.md")
    chart_path = resolve_sandboxed_path(f"{clean_stem}.png", EXPORT_DIR, "chart.png")

    engine = AnalyticsEngine(records)
    summary = engine.executive_summary()
    created: list[Path] = []

    with csv_path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["student_id", "student_name", "subject", "score", "grade", "status", "term", "date"])
        for r in records:
            writer.writerow(
                [
                    neutralize_csv_cell(r.student_id),
                    neutralize_csv_cell(r.student_name),
                    neutralize_csv_cell(r.subject),
                    r.score,
                    neutralize_csv_cell(r.grade),
                    neutralize_csv_cell(r.status),
                    neutralize_csv_cell(r.term),
                    neutralize_csv_cell(r.recorded_at),
                ]
            )
    created.append(csv_path)

    lines = [
        "# Academic Performance Executive Report",
        f"- **Generated:** {dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"- **Total Records:** {summary['count']}",
        f"- **Mean Score:** {summary['mean']} | **Median:** {summary['median']} | **Std Dev:** {summary['stdev']}",
        f"- **Pass Rate (>= {PASS_THRESHOLD}):** {summary['pass_rate']}% | **Honors (>= {HONORS_THRESHOLD}):** {summary['honors_count']} | **At-Risk:** {summary['at_risk_count']}",
        "",
        "## Subject Breakdown",
        "| Subject | Count | Avg | Std Dev | Min | Max | Trend Slope |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for subj, stats in summary["subjects"].items():
        lines.append(
            f"| {subj} | {stats['count']} | {stats['avg']} | {stats['stdev']} | {stats['min']} | {stats['max']} | {stats['slope']:+.2f} |"
        )
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    created.append(md_path)

    if HAS_MATPLOTLIB and summary["subjects"]:
        subjects = list(summary["subjects"].keys())
        avgs = [summary["subjects"][s]["avg"] for s in subjects]
        fig, ax = plt.subplots(figsize=(8, 4.5))
        bars = ax.bar(subjects, avgs)
        ax.axhline(PASS_THRESHOLD, linestyle="--", linewidth=1.2, label=f"Pass ({PASS_THRESHOLD})")
        ax.axhline(HONORS_THRESHOLD, linestyle=":", linewidth=1.2, label=f"Honors ({HONORS_THRESHOLD})")
        ax.set_ylim(0, 105)
        ax.set_ylabel("Average Score")
        ax.set_title("Subject-Wise Average Performance")
        ax.legend()
        for bar, val in zip(bars, avgs):
            ax.text(bar.get_x() + bar.get_width() / 2, val + 1.5, f"{val:.1f}", ha="center", fontsize=9)
        fig.tight_layout()
        fig.savefig(chart_path, dpi=150)
        plt.close(fig)
        created.append(chart_path)

    write_audit_log("EXPORT_REPORTS", f"Generated {[p.name for p in created]}")
    return created


# ==============================================================================
# Interactive CLI & Display Routines
# ==============================================================================
def prompt_non_empty(label: str, max_len: int = MAX_TEXT_LEN) -> str:
    while True:
        raw = input(f"{label}: ")
        try:
            return sanitize_text(raw, label, max_len)
        except ValueError as exc:
            print(f"  [!] {exc}")


def prompt_score_loop() -> float:
    while True:
        raw = input("Score (0-100): ")
        try:
            return validate_score(raw)
        except ValueError as exc:
            print(f"  [!] {exc}")


def print_records_table(records: list[PerformanceRecord], page_size: int = 12) -> None:
    if not records:
        print("No matching records found.")
        return

    print(f"\n{'ID':<8} {'Student':<20} {'Subject':<18} {'Score':>6} {'Grade':>5} {'Status':<8} {'Date':<10}")
    print("-" * 82)
    for idx, r in enumerate(records, start=1):
        print(
            f"{r.student_id:<8} {r.student_name[:20]:<20} {r.subject[:18]:<18} "
            f"{r.score:>6.1f} {r.grade:>5} {r.status:<8} {r.recorded_at:<10}"
        )
        if idx % page_size == 0 and idx < len(records):
            cont = input("-- Press Enter for next page (or 'q' to stop listing) -- ").strip().lower()
            if cont == "q":
                break


def print_ascii_subject_bars(subjects: dict[str, dict[str, Any]]) -> None:
    print("\nSubject Performance Bars (0-100 scale):")
    for subj, st in subjects.items():
        filled = int(round(st["avg"] / 5))
        bar = "#" * filled + "." * (20 - filled)
        print(f"  {subj:<18} [{bar}] {st['avg']:>5.1f} (slope {st['slope']:+.2f})")


def show_executive_dashboard(records: list[PerformanceRecord]) -> None:
    engine = AnalyticsEngine(records)
    summary = engine.executive_summary()
    print("\n=== EXECUTIVE PERFORMANCE SUMMARY ===")
    print(f"Records: {summary['count']} | Mean: {summary['mean']} | Median: {summary['median']} | StdDev: {summary['stdev']}")
    print(f"Range: {summary['min']} - {summary['max']} | Pass Rate: {summary['pass_rate']}% | Honors: {summary['honors_count']} | At-Risk: {summary['at_risk_count']}")

    if summary["subjects"]:
        print_ascii_subject_bars(summary["subjects"])

    anomalies = engine.detect_anomalies()
    print(f"\n=== THRESHOLD & ANOMALY ALERTS ({len(anomalies)}) ===")
    if not anomalies:
        print("No threshold breaches or statistical anomalies detected.")
    else:
        for rec, z_val, reason in anomalies[:15]:
            print(f"  [WARN] {rec.student_id} ({rec.student_name}) - {rec.subject}: {rec.score} | {reason}")


def run_cli() -> None:
    records = load_records_with_recovery()
    print("\n========================================================")
    print("   ACADEMIC PERFORMANCE DASHBOARD (HARDENED EDITION)   ")
    print("========================================================")
    print(f"Loaded {len(records)} records | Matplotlib available: {HAS_MATPLOTLIB}")

    while True:
        print("\nMenu:")
        print("  1. Add Record (Validated)")
        print("  2. View / Search Records")
        print("  3. Executive Summary & Anomaly Alerts")
        print("  4. Bulk Import CSV (from data/)")
        print("  5. Export Reports (CSV, Markdown & Chart)")
        print("  6. Exit")

        choice = input("Select option [1-6]: ").strip()
        try:
            if choice == "1":
                sid = prompt_non_empty("Student ID (e.g. STU013)", 24)
                name = prompt_non_empty("Student Name", MAX_TEXT_LEN)
                subj = prompt_non_empty("Subject", 50)
                score = prompt_score_loop()
                term = prompt_non_empty("Term (e.g. Term 1)", 24)
                rec = PerformanceRecord(student_id=sid, student_name=name, subject=subj, score=score, term=term)
                records.append(rec)
                save_records_atomic(records)
                print(f"[OK] Saved {rec.student_id} - {rec.subject}: {rec.score} ({rec.grade}, {rec.status})")

            elif choice == "2":
                query = input("Filter by student/subject/status (blank for all): ").strip().lower()
                if not query:
                    filtered = records
                else:
                    filtered = [
                        r
                        for r in records
                        if query in r.student_id.lower()
                        or query in r.student_name.lower()
                        or query in r.subject.lower()
                        or query in r.status.lower()
                    ]
                print_records_table(filtered)

            elif choice == "3":
                show_executive_dashboard(records)

            elif choice == "4":
                fname = input("CSV filename inside data/ (e.g. sample_import.csv): ").strip()
                added, errs = import_csv_records(fname, records)
                print(f"[OK] Imported {added} valid record(s). Errors: {len(errs)}")
                for e in errs[:10]:
                    print(f"  [ERR] {e}")

            elif choice == "5":
                stem = input("Report base name [academic_report]: ").strip() or "academic_report"
                files = export_reports(records, stem)
                print("[OK] Exported files:")
                for f in files:
                    print(f"  - {f.relative_to(BASE_DIR)}")

            elif choice == "6":
                save_records_atomic(records)
                print("Goodbye. Session state saved securely.")
                break

            else:
                print("Please choose a valid option from 1 to 6.")

        except (ValueError, SecurityError, OSError) as exc:
            print(f"[BLOCKED/ERROR] {exc}")


if __name__ == "__main__":
    try:
        run_cli()
    except KeyboardInterrupt:
        print("\nInterrupted by user. Exiting cleanly.")
        sys.exit(0)


# ==============================================================================
# Extended Student Profiles, Term Analytics & Integrity Inspection (v2)
# ==============================================================================
def score_to_grade_point(score: float) -> float:
    if score >= 90:
        return 10.0
    if score >= 80:
        return 9.0
    if score >= 70:
        return 8.0
    if score >= 60:
        return 7.0
    if score >= PASS_THRESHOLD:
        return 6.0
    return 0.0


def build_student_profiles(records: list[PerformanceRecord]) -> list[dict[str, Any]]:
    grouped: dict[str, list[PerformanceRecord]] = {}
    for r in records:
        grouped.setdefault(r.student_id, []).append(r)

    profiles: list[dict[str, Any]] = []
    for sid, items in sorted(grouped.items()):
        avg_score = round(statistics.fmean(x.score for x in items), 2)
        cgpa = round(statistics.fmean(score_to_grade_point(x.score) for x in items), 2)
        best = max(items, key=lambda x: x.score)
        weakest = min(items, key=lambda x: x.score)
        at_risk_subjects = sum(1 for x in items if x.score < PASS_THRESHOLD)
        if at_risk_subjects > 0:
            standing = "AT_RISK"
        elif avg_score >= HONORS_THRESHOLD:
            standing = "HONORS"
        else:
            standing = "GOOD_STANDING"

        profiles.append(
            {
                "student_id": sid,
                "student_name": items[-1].student_name,
                "subjects_count": len(items),
                "average": avg_score,
                "cgpa_10": cgpa,
                "best_subject": f"{best.subject} ({best.score:.1f})",
                "weakest_subject": f"{weakest.subject} ({weakest.score:.1f})",
                "at_risk_subjects": at_risk_subjects,
                "standing": standing,
            }
        )
    return profiles


def verify_state_integrity() -> tuple[bool, str, str, int]:
    ensure_directories()
    backups = sorted(BACKUP_DIR.glob("records_*.json"))
    if not STATE_FILE.exists():
        return True, "No saved state file yet (will seed on load).", "N/A", len(backups)
    raw = STATE_FILE.read_bytes()
    actual = compute_sha256_bytes(raw)
    if not MANIFEST_FILE.exists():
        return False, "Missing SHA-256 manifest file.", actual[:16], len(backups)
    expected = MANIFEST_FILE.read_text(encoding="utf-8").strip().split()[0]
    if hmac.compare_digest(actual, expected):
        return True, "SHA-256 manifest verified intact.", actual[:16], len(backups)
    return False, "SHA-256 mismatch detected!", actual[:16], len(backups)


def get_recent_audit_entries(limit: int = 15) -> list[str]:
    if not AUDIT_LOG_FILE.exists():
        return []
    lines = [ln for ln in AUDIT_LOG_FILE.read_text(encoding="utf-8").splitlines() if ln.strip()]
    return list(reversed(lines[-max(1, int(limit)):]))
