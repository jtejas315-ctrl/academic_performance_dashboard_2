# Academic Performance Dashboard — Rose Pink Edition (v3 CSS & Palette Upgrade)

This version features an expanded **Rose & Magenta Pink** stylesheet (`static/theme_pink.css`) with **Rose Pink Light** and **Rose Pink Dark** modes, glassmorphic metric cards, hover transitions, gradient hero styling, and all v2 CGPA, multi-facet filtering, record editing/deletion, CSV import, and SHA-256/HMAC integrity features.

## Quick Start (Windows PowerShell)
```powershell
cd academic_performance_dashboard
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m streamlit run dashboard_app.py
```
